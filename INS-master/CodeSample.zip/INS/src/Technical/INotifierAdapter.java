package Technical;

public interface INotifierAdapter {
	public void sendNotification();

}
